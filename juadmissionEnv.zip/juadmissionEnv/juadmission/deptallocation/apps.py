from django.apps import AppConfig


class DeptallocationConfig(AppConfig):
    name = 'deptallocation'
