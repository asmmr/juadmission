from django.apps import AppConfig


class DeptchoiceConfig(AppConfig):
    name = 'deptchoice'
