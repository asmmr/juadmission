from django.apps import AppConfig


class DeptmigrationConfig(AppConfig):
    name = 'deptmigration'
