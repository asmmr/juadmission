from django.apps import AppConfig


class DeptchoiceverificationConfig(AppConfig):
    name = 'deptchoiceverification'
